package com.rentablezone.app

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class OverlayView(context: Context) : LinearLayout(context) {
    private val title = TextView(context)
    private val detail = TextView(context)

    init {
        orientation = VERTICAL
        gravity = Gravity.START
        setPadding(16, 10, 16, 10)
        val bg = GradientDrawable().apply {
            setColor(Color.argb(210, 20, 30, 45))
            cornerRadius = 22f
            setStroke(1, Color.argb(90, 255, 255, 255))
        }
        background = bg
        title.setTextColor(Color.WHITE)
        title.textSize = 17f
        title.setTypeface(null, android.graphics.Typeface.BOLD)
        detail.setTextColor(Color.WHITE)
        detail.textSize = 13.5f
        detail.setLineSpacing(0f, 1.05f)
        addView(title, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        addView(detail, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
    }

    fun showResult(result: Analysis) {
        visibility = VISIBLE
        title.text = result.label
        title.setTextColor(result.color)
        detail.text = result.detail
    }

    fun hideResult() {
        visibility = INVISIBLE
    }

    fun setBackgroundAlpha(alphaPercent: Int) {
        val a = (255 * alphaPercent.coerceIn(5, 100) / 100f).toInt()
        background?.alpha = a
    }
}

data class Analysis(
    val label: String,
    val detail: String,
    val color: Int,
    val destination: String = ""
) {
    fun withZone(type: Int?): Analysis {
        val suffix = when (type) {
            2 -> "\n🔴 ZONA PELIGROSA"
            1 -> "\n🟡 ZONA DE PRECAUCIÓN"
            0 -> "\n🟢 ZONA PERMITIDA"
            else -> "\n⚪ ZONA NO DETERMINADA"
        }
        return copy(detail = detail + suffix)
    }
}
