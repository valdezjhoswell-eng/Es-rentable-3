package com.rentablezone.app

import android.content.Context
import org.osmdroid.util.GeoPoint
import org.json.JSONArray
import org.json.JSONObject

data class SavedZone(val type: Int, val points: List<GeoPoint>)

object ZoneStore {
    private const val PREFS = "zones"
    private const val KEY = "saved_zones"

    fun load(context: Context): List<SavedZone> {
        val raw = context.getSharedPreferences(PREFS, 0).getString(KEY, "[]") ?: "[]"
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val pts = obj.getJSONArray("p")
                    val list = buildList {
                        for (j in 0 until pts.length()) {
                            val point = pts.getJSONObject(j)
                            add(GeoPoint(point.getDouble("lat"), point.getDouble("lng")))
                        }
                    }
                    if (list.size >= 3) add(SavedZone(obj.getInt("t").coerceIn(0, 2), list))
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun save(context: Context, zones: List<SavedZone>) {
        val array = JSONArray()
        zones.forEach { zone ->
            val obj = JSONObject().put("t", zone.type.coerceIn(0, 2))
            val points = JSONArray()
            zone.points.forEach { point ->
                points.put(
                    JSONObject()
                        .put("lat", point.latitude)
                        .put("lng", point.longitude)
                )
            }
            obj.put("p", points)
            array.put(obj)
        }
        context.getSharedPreferences(PREFS, 0)
            .edit()
            .putString(KEY, array.toString())
            .apply()
    }

    /**
     * Devuelve la zona definida por el usuario que contiene el punto.
     * Si hay polígonos superpuestos, roja tiene prioridad sobre amarilla y verde.
     */
    fun zoneFor(context: Context, latitude: Double, longitude: Double): Int? {
        val point = GeoPoint(latitude, longitude)
        return load(context)
            .asSequence()
            .filter { it.points.size >= 3 && contains(it.points, point) }
            .map { it.type }
            .maxOrNull()
    }

    private fun contains(polygon: List<GeoPoint>, point: GeoPoint): Boolean {
        var inside = false
        var j = polygon.lastIndex

        for (i in polygon.indices) {
            val xi = polygon[i].longitude
            val yi = polygon[i].latitude
            val xj = polygon[j].longitude
            val yj = polygon[j].latitude
            val intersects = ((yi > point.latitude) != (yj > point.latitude)) &&
                (point.longitude < (xj - xi) * (point.latitude - yi) / (yj - yi + 1e-12) + xi)
            if (intersects) inside = !inside
            j = i
        }
        return inside
    }
}
